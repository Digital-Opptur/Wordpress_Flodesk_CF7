<?php
	/**
	Name: admin.php
	Description: Create a admin page for our plugin, so the user can enter the necessary information
	*/

?>